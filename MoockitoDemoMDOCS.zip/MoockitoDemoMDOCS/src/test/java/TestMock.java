import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import java.util.Iterator;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mock.Maths;
public class TestMock 
{
	@Test
	public void testMockA()
	{
		int a=10,b=20;
Maths m=mock(Maths.class);
when(m.add(a,b)).thenReturn(a+b);
assertEquals(30,m.add(a,b));
}
	@DisplayName("Testing Subtraction of 2 nos")
	@Order(3)
	@Test
	public void testMockB()
	{
		int a=10,b=20;
Maths m=mock(Maths.class);
when(m.sub(a,b)).thenReturn(a-b);
assertEquals(-10,m.sub(a,b));
}
	@DisplayName("Testing Multiply 2 nos")
	@Order(2)
	@Test
public void testMockC()
	{
		int a=10,b=20;
Maths m=mock(Maths.class);
when(m.mul(a,b)).thenReturn(a*b);
assertEquals(200,m.mul(a,b));
}
@DisplayName("Testing Divide 2 nos")
	@Test
	@Order(1)
public void testMockD()
	{
		int a=20,b=10;
Maths m=mock(Maths.class);
when(m.div(a,b)).thenReturn(a/b);
assertEquals(2,m.div(a,b));
}


}