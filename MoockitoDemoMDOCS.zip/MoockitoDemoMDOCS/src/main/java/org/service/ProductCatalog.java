package org.service;
import org.mock.Maths;
public class ProductCatalog 
{
private Maths m;
public ProductCatalog(Maths m)
{
	this.m = m;
}
public String getMsg1(int len,int wid)
{
	return "The sum is :"+m.add(len,wid);
}

public String getMsg2(int len,int wid)
{
	return "The sub is :"+m.sub(len,wid);
}

public String getMsg3(int len,int wid)
{
	return "The mul is :"+m.mul(len,wid);
}

public String getMsg4(int len,int wid)
{
	return "The div is :"+m.div(len,wid);
}
}
